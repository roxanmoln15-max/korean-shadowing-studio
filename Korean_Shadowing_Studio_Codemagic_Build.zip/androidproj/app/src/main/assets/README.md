# Shadowing Studio — koreai árnyékolás gyakorló

Standalone, böngészőben futó magyar felület. Az app a lejátszási listákat, szöveges előzményeket és hibákat a böngésző LocalStorage-ban, a felvételeket IndexedDB-ben tárolja.

## Indítás

- **Ajánlott:** a mappát szolgáld ki localhoston (mikrofon és böngészőmodulok miatt): `python -m http.server 8000`, majd nyisd meg `http://localhost:8000`.
- HTTPS-en is működhet; a mikrofonhoz HTTPS vagy localhost szükséges, és a böngésző engedélye kell.
- Egyszerű `file://` megnyitás esetén a böngésző korlátozhatja a mikrofont vagy a modulokat.

## Használat

1. Illessz be egy YouTube-linket, és válaszd a Betöltés gombot. Vagy tölts fel saját audio/video fájlt.
2. Állítsd be a kezdő és vég időpontot (másodpercben), a sebességet és az ismétlésszámot, majd indítsd a szakasz lejátszását.
3. Készíts mikrofonos felvételt. Lejátszható és letölthető. A mentés gomb a felvételt a kiválasztott lista szakaszához társítja.
4. Add meg a referencia koreai szöveget, töltsd be a Whisper Tiny-t, majd ismerd fel a beszédet. Az összehasonlítás a szöveges eltéréseket és egy egyszerű token-alapú hasonlósági pontszámot mutat.
5. A mentett szakaszok listákban rendezhetők, átnevezhetők, szerkeszthetők, törölhetők. A saját fájlokat IndexedDB-ben próbálja tárolni, így mentett szakasz lejátszása és WAV-exportja újratöltés után is elérhető lehet; a tárhelykapacitás és dekódolhatóság böngészőfüggő.

## Whisper és adatvédelem

- A Transformers.js és a Xenova Whisper Tiny modell CDN-en keresztül, első használatkor internetkapcsolattal töltődik be. A modell inferenciája a böngészőben, WebAssembly használatával fut; nincs API-kulcs, előfizetés vagy fizetett backend. A modell letöltése és cache-elése a böngésző által kezelt folyamat.
- YouTube videók beágyazott lejátszón keresztül szólalnak meg. Az app **nem tölti le a YouTube hangját**; URL-t és időpontokat tárol.
- A mikrofonfelvétel és app adatai helyi böngésző-tárolóba kerülnek.
- A beszéd szöveggé alakítása és szöveges összehasonlítása **nem** fonéma-alapú kiejtésvizsgálat. A szöveges pontszám nem mér intonációt, hangképzést, akcentust vagy fonetikai pontosságot.

## WAV export korlát

WAV export a mentett vagy aktuálisan betöltött, dekódolható audiofájl kiválasztott időszakaszát vágja ki, csatornákat mono hanggá keverve és PCM WAV fájlként tölti le. A böngészők nem dekódolnak minden videó konténert/audio sávot egyformán; a videókból való audio dekódolás és WAV export nem garantált. A YouTube audiót nem lehet így exportálni. A mentett fájl tartós tárolása IndexedDB-t használ, ami nagy fájloknál vagy kevés tárhely esetén hibázhat.

## Böngésző-kompatibilitás

Friss Chromium-alapú böngésző (Chrome/Edge/Android Chrome) ajánlott. A mikrofon, IndexedDB, MediaRecorder, YouTube IFrame API és Transformers.js működését böngésző és rendszer beállításai befolyásolhatják.


## Javított csomag (2026-11-27)

- A felvételhez kapcsolódó mentés kattintáskezelőjének hibáját eltávolítottuk, amely korábban törölhette a társítási kulcsot.
- Saját fájlok mentése IndexedDB-ben; mentett saját szakasz visszatöltése és lejátszása, illetve WAV kivágás a tárolt fájl alapján.
- WAV export több audio-csatornát mono mixbe kever.
- Whisper felismerés saját audio vagy videó fájlra is megpróbálható (dekódolási kompatibilitástól függően).
- A módosított JavaScript szintaxisát Node ellenőrző futtatásával validáltuk. A teljes böngészős tesztet a környezet navigációs korlátozása miatt nem sikerült elvégezni.

## Új funkciók (2026-11)
- Külön videó-idővonal csúszka, −/+ 5 másodperces navigáció, valamint a jelenlegi időpont kezdő/végpontként rögzítése.
- SRT/VTT felirat beillesztésével mondatjelölő: az udvarias koreai végződéseket heurisztikusan előnyben részesíti, banmal-gyanús sorokat kiszűri, a kiválasztott időzített mondatokat listába menti.
- A mondatszűrő nem generatív AI, és nem garantál nyelvileg helyes besorolást. Az időzített felirat feldolgozásához SRT/VTT szükséges; a YouTube feliratát az alkalmazás nem tölti le automatikusan.


## Audit notes (2026-11-27)
- Added readiness handling for the YouTube iframe API and clearer player errors.
- Improved YouTube URL parsing (including live links), Whisper loading concurrency, channel downmix, and persistence failure reporting.
- WAV export is explicitly unavailable for YouTube-only saved clips; it requires a local audio/video file with decodable audio.
- Caption filtering remains a heuristic and is not a generative AI or guaranteed banmal detector.
- A full browser interaction test is still required on the user's browser because this environment blocks browser navigation.

### Könyvtári nagy előnézet és feliratok
A mentett YouTube-szakasz kártyája nagyobb lejátszó-előnézetet kapott, és a mentett koreai referencia/felirat jól olvasható méretben jelenik meg alatta. Az embed feliratokat is kér (ha a videóhoz elérhetők, a YouTube feliratvezérlője használható). A felirat kézi hozzáadása/szerkesztése a szakasz Szerkesztés funkciójával lehetséges.

### Mikrofon
A mikrofonfelvétel HTTPS vagy localhost környezetet igényel, és a Chrome webhelyengedélyét. A felület most külön jelzi a nem biztonságos környezetet, a hiányzó MediaRecorder API-t és a gyakori engedélyhibákat.
