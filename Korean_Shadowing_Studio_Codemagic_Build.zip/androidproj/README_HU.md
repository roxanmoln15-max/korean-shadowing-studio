# Korean Shadowing Studio – APK build csomag

Ez a projekt a meglévő Korean Shadowing Studio webalkalmazást Android WebView alkalmazásba csomagolja. A Codemagic felhőben készíti el belőle a telepíthető Android APK-t; ehhez nem kell Android Studio vagy számítógépes Android SDK.

## Mi van a csomagban?
- A webapp teljes forrása az `app/src/main/assets/` mappában.
- Android WebView-keret, saját lila ㄱ alkalmazásikonnal.
- Android fájlválasztó hang- és videófájlokhoz, mikrofonengedély és helyi WebView-tárhely.
- `codemagic.yaml`: automatikus felhős APK-build.
- `gradlew`: letölti a Gradle 8.9-et a buildkörnyezetben, így nem kell külön wrapper JAR-t telepíteni.

## Egyszeri beállítás telefonról
1. Nyisd meg a GitHubot, és hozz létre egy új, **Private** repositoryt, például `korean-shadowing-studio` néven: https://github.com/new
2. A repositoryban válaszd az **Add file → Upload files** lehetőséget.
3. Csomagold ki ezt a ZIP-et a telefonodon, majd töltsd fel a ZIP-ben lévő projektfájlokat és mappákat a repository gyökerébe. Fontos: a `codemagic.yaml`, `gradlew`, `settings.gradle` és `app/` közvetlenül a repository gyökerében legyen.
4. Mentsd el a feltöltést (**Commit changes**).
5. Nyisd meg a https://codemagic.io/ oldalt, jelentkezz be, és csatlakoztasd a GitHub-fiókodat.
6. Válaszd ki az új repositoryt. A Codemagic a gyökérben megtalálja a `codemagic.yaml` fájlt. Indítsd el a `Korean Shadowing Studio - Android APK` workflow-t.
7. Sikeres build után a build oldal **Artifacts** részében töltsd le az `app-debug.apk` fájlt a Samsung telefonodra, majd nyisd meg és telepítsd.

## Build részletei
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Java: 17-es futtatókörnyezet szükséges (a Codemagic Android buildkörnyezet biztosítja).
- APK-típus: debug APK. Tesztelésre és közvetlen telefonos telepítésre alkalmas; Google Play publikáláshoz külön aláírt release build kell.

## Megjegyzések
- Az első build letölti a Gradle-t és az Android-függőségeket, ezért tovább tarthat.
- A YouTube beágyazott lejátszó korlátozásai az alkalmazásban is érvényesek.
- A Whisper Tiny modell első betöltése internetkapcsolatot igényel.
- A mentések az alkalmazás helyi WebView-tárhelyében maradnak. Az alkalmazás eltávolítása vagy adatainak törlése törölheti őket.
- A felhőbuildet és az APK-t még nem futtattuk le; a projektet előkészítettük a Codemagic számára, de a sikeres fordítás csak a repository csatlakoztatása és a build elindítása után igazolható.
